/*
 * betweenFactorSwitchable.cpp
 *
 *  Created on: 02.08.2012
 *      Author: niko
 */


namespace robust_gtsam
{


}
