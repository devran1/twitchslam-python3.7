#include <pybind11/pybind11.h>

#include <pangolin//.h>


namespace py = pybind11;
using namespace pybind11::literals;


namespace pangolin {

void declareHandlerEnums(py::module & m) {



}

}